# InShortsClone
This is the layout clone for a news app, InShorts

[Video](https://vimeo.com/265922320).
